"""
Dashboard application package.
""" 