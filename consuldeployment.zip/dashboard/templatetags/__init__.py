"""
Template tags and filters for the dashboard application.
""" 