"""
Models for the dashboard app.

This app primarily uses Supabase for data storage, so no Django models are needed at this time.
"""
# No models needed - using Supabase for data storage 