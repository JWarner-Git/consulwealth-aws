"""
Django management commands for the dashboard app.
""" 