"""
Migrations for the dashboard app.
""" 