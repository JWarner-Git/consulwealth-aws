"""
Migrations for the supabase_integration app.
""" 