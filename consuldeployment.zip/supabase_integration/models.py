"""
Models for the supabase_integration app.
"""
# No models needed - using Supabase for data storage 