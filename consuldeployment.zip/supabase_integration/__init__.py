"""
Supabase integration package.
This package provides integration with Supabase for authentication and data storage.
"""

__version__ = '0.1.0'

default_app_config = 'supabase_integration.apps.SupabaseIntegrationConfig'
