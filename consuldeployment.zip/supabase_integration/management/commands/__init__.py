"""
Management commands for supabase_integration.
These commands help manage the Supabase integration.
""" 