"""
Custom template tags and filters for the dashboard application.
""" 