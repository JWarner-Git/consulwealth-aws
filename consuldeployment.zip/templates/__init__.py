"""
Templates package.
""" 