-- SQL script to update the plaid_items table with new columns for Plaid refresh strategy
-- Run this in the Supabase SQL Editor

-- Create the plaid_items table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.plaid_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    item_id TEXT NOT NULL,
    access_token TEXT NOT NULL,
    institution_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure institution_id is TEXT type (in case it was defined as UUID incorrectly)
DO $$
BEGIN
    IF EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'plaid_items'
        AND column_name = 'institution_id'
        AND data_type <> 'text'
    ) THEN
        ALTER TABLE public.plaid_items 
        ALTER COLUMN institution_id TYPE TEXT USING institution_id::TEXT;
    END IF;
END $$;

-- Add connection_status column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'plaid_items'
        AND column_name = 'connection_status'
    ) THEN
        ALTER TABLE public.plaid_items ADD COLUMN connection_status TEXT DEFAULT 'active';
    END IF;
END $$;

-- Add update_type column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'plaid_items'
        AND column_name = 'update_type'
    ) THEN
        ALTER TABLE public.plaid_items ADD COLUMN update_type TEXT DEFAULT 'initial';
    END IF;
END $$;

-- Add last_successful_update column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'plaid_items'
        AND column_name = 'last_successful_update'
    ) THEN
        ALTER TABLE public.plaid_items ADD COLUMN last_successful_update TIMESTAMPTZ DEFAULT NOW();
    END IF;
END $$;

-- Add last_connection_time column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'plaid_items'
        AND column_name = 'last_connection_time'
    ) THEN
        ALTER TABLE public.plaid_items ADD COLUMN last_connection_time TIMESTAMPTZ DEFAULT NOW();
    END IF;
END $$;

-- Add next_hard_refresh column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'plaid_items'
        AND column_name = 'next_hard_refresh'
    ) THEN
        ALTER TABLE public.plaid_items ADD COLUMN next_hard_refresh TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '90 days');
    END IF;
END $$;

-- Comment on the new columns to explain their purpose
COMMENT ON COLUMN public.plaid_items.connection_status IS 'Status of the Plaid connection (active, inactive, error)';
COMMENT ON COLUMN public.plaid_items.update_type IS 'Type of the last update (initial, soft, hard)';
COMMENT ON COLUMN public.plaid_items.last_successful_update IS 'Timestamp of the last successful update';
COMMENT ON COLUMN public.plaid_items.last_connection_time IS 'Timestamp of the last connection/authentication';
COMMENT ON COLUMN public.plaid_items.next_hard_refresh IS 'Timestamp when the next hard refresh should be performed';

-- Update any existing items to have the current timestamp for the new columns
UPDATE public.plaid_items 
SET 
    last_successful_update = NOW(),
    last_connection_time = NOW(),
    next_hard_refresh = NOW() + INTERVAL '90 days'
WHERE 
    last_successful_update IS NULL
    OR last_connection_time IS NULL
    OR next_hard_refresh IS NULL; 