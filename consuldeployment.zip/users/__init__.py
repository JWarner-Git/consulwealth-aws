"""
Users app for the application. 
This app provides user models, authentication, and profiles.
"""
