"""
Core Django project settings and configuration.
"""
